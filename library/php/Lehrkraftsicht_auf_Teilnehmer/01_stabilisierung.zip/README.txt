FRZK Analysepaket 01_stabilisierung

1. Export:
   python export_stabilisierung_lehrkraftdaten.py

2. Darstellung/Auswertung:
   python auswertung_stabilisierung_lehrkraftdaten.py

Voraussetzungen:
   pip install pandas numpy matplotlib mysql-connector-python
