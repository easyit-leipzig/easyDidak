
from frzk_common import *

ANALYSE_NR = 1
OUTPUT_JSON = "frzk_stabilisierung_lehrkraftdaten.json"
TITLE = "1. Stabilisierungsvorhersage des FRZK"
INTERPRETATION = "Geringere Streuung, geringere Vektordrift und höhere Wiederholungsstabilität deuten auf FRZK-konforme Stabilisierung hin."

def analyze_subset(dataframe, label):
    dataframe = dataframe.copy()
    teilnehmer = []

    

    for tid, g in dataframe.groupby("teilnehmer_id"):
        
        dim_std = {d.replace("x_", ""): safe_float(g[d].std(ddof=0)) for d in DIMENSIONS}
        dim_range = {d.replace("x_", ""): safe_float(g[d].max() - g[d].min()) for d in DIMENSIONS}
        d_std = safe_float(g["d_semantisch"].std(ddof=0))
        delta_mean = safe_float(g["delta_vektor"].dropna().mean())
        stabilisierungsindex = 1 / (1 + (d_std or 0) + sum(v or 0 for v in dim_std.values()) + (delta_mean or 0))
        teilnehmer.append({
            "teilnehmer_id": int(tid), "n": int(len(g)),
            "datum_von": str(g["datum"].min().date()), "datum_bis": str(g["datum"].max().date()),
            "d_semantisch_mean": safe_float(g["d_semantisch"].mean()),
            "d_semantisch_std": d_std,
            "delta_vektor_mean": delta_mean,
            "delta_vektor_std": safe_float(g["delta_vektor"].dropna().std(ddof=0)),
            "dimension_std": dim_std,
            "dimension_range": dim_range,
            "dominanz_breite": int(g["dominante_dimension"].nunique()),
            "polaritaet_std": safe_float(g["polaritaet_gesamt"].std(ddof=0)),
            "stabilisierungsindex": safe_float(stabilisierungsindex),
        })


    def extra_gesamt(tdf, dataframe):
        
        return {
            "mittlerer_stabilisierungsindex": safe_float(tdf["stabilisierungsindex"].mean()) if not tdf.empty else None,
            "d_semantisch_std": safe_float(dataframe["d_semantisch"].std(ddof=0)),
            "delta_vektor_mean": safe_float(dataframe["delta_vektor"].dropna().mean()),
        }


    return base_block(dataframe, label, teilnehmer, extra_gesamt)

df = load_data()
df = add_transitions(df)
write_json(
    OUTPUT_JSON,
    TITLE,
    INTERPRETATION,
    split_groups(df, analyze_subset)
)
