
from frzk_common import *

ANALYSE_NR = 8
OUTPUT_JSON = "frzk_attraktor_nachweis_lehrkraftdaten.json"
TITLE = "8. Attraktor-Nachweis des FRZK"
INTERPRETATION = "Attraktoren zeigen sich durch wiederkehrende ähnliche Zustände und dominante Zustandsräume."

def analyze_subset(dataframe, label):
    dataframe = dataframe.copy()
    teilnehmer = []

    

    for tid, g in dataframe.groupby("teilnehmer_id"):
        
        vals = g[DIMENSIONS].to_numpy(dtype=float)
        hits90 = hits95 = total = 0
        for i in range(len(vals)):
            for j in range(i+1, len(vals)):
                den = np.linalg.norm(vals[i]) * np.linalg.norm(vals[j])
                if den:
                    c = float(np.dot(vals[i], vals[j]) / den)
                    total += 1
                    hits90 += int(c >= 0.90)
                    hits95 += int(c >= 0.95)
        rec90 = hits90 / total if total else None
        rec95 = hits95 / total if total else None
        dom = g["dominante_dimension"].value_counts()
        attr = safe_float(dom.max() / len(g)) if len(g) else None
        teilnehmer.append({
            "teilnehmer_id": int(tid), "n": int(len(g)),
            "datum_von": str(g["datum"].min().date()), "datum_bis": str(g["datum"].max().date()),
            "recurrence_rate_090": safe_float(rec90),
            "recurrence_rate_095": safe_float(rec95),
            "attraktor_staerke": attr,
            "cluster_persistenz": safe_float(1 - g["dominanzwechsel"].dropna().mean()),
            "d_semantisch_std": safe_float(g["d_semantisch"].std(ddof=0)),
        })


    def extra_gesamt(tdf, dataframe):
        
        return {
            "recurrence_rate_090_mean": safe_float(tdf["recurrence_rate_090"].mean()) if not tdf.empty else None,
            "recurrence_rate_095_mean": safe_float(tdf["recurrence_rate_095"].mean()) if not tdf.empty else None,
            "attraktor_staerke_mean": safe_float(tdf["attraktor_staerke"].mean()) if not tdf.empty else None,
        }


    return base_block(dataframe, label, teilnehmer, extra_gesamt)

df = load_data()
df = add_transitions(df)
write_json(
    OUTPUT_JSON,
    TITLE,
    INTERPRETATION,
    split_groups(df, analyze_subset)
)
