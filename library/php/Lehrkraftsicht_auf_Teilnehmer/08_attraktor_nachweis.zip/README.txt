FRZK Analysepaket 08_attraktor_nachweis

1. Export:
   python export_attraktor_nachweis_lehrkraftdaten.py

2. Darstellung/Auswertung:
   python auswertung_attraktor_nachweis_lehrkraftdaten.py

Voraussetzungen:
   pip install pandas numpy matplotlib mysql-connector-python
