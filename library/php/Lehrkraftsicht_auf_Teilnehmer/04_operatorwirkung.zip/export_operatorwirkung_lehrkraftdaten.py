
from frzk_common import *

ANALYSE_NR = 4
OUTPUT_JSON = "frzk_operatorwirkung_lehrkraftdaten.json"
TITLE = "4. Operatorwirkung des FRZK"
INTERPRETATION = "Operatorwirkung zeigt sich in Ambivalenz, Dominanzwechseln, Polaritätswechseln und Vektordrift."

def analyze_subset(dataframe, label):
    dataframe = dataframe.copy()
    teilnehmer = []

    
    dataframe["vektorbetrag"] = np.sqrt((dataframe[DIMENSIONS] ** 2).sum(axis=1))
    dataframe["positive_dimensionen"] = (dataframe[DIMENSIONS] > 0).sum(axis=1)
    dataframe["negative_dimensionen"] = (dataframe[DIMENSIONS] < 0).sum(axis=1)
    dataframe["ambivalenz_index"] = (dataframe["positive_dimensionen"] * dataframe["negative_dimensionen"]) / 12.0
    dataframe["operatorwirkung_proxy"] = (
        dataframe["ambivalenz_index"] + dataframe["vektorbetrag"] + dataframe["dominante_dimension_wert"].abs()
    ) / 3


    for tid, g in dataframe.groupby("teilnehmer_id"):
        
        teilnehmer.append({
            "teilnehmer_id": int(tid), "n": int(len(g)),
            "datum_von": str(g["datum"].min().date()), "datum_bis": str(g["datum"].max().date()),
            "operatorwirkung_proxy_mean": safe_float(g["operatorwirkung_proxy"].mean()),
            "operatorwirkung_proxy_std": safe_float(g["operatorwirkung_proxy"].std(ddof=0)),
            "ambivalenz_mean": safe_float(g["ambivalenz_index"].mean()),
            "dominanzwechsel_rate": safe_float(g["dominanzwechsel"].dropna().mean()),
            "polaritaetswechsel_rate": safe_float(g["polaritaetswechsel"].dropna().mean()),
            "delta_vektor_mean": safe_float(g["delta_vektor"].dropna().mean()),
            "positive_dimensionen_mean": safe_float(g["positive_dimensionen"].mean()),
            "negative_dimensionen_mean": safe_float(g["negative_dimensionen"].mean()),
        })


    def extra_gesamt(tdf, dataframe):
        
        return {
            "operatorwirkung_proxy_mean": safe_float(dataframe["operatorwirkung_proxy"].mean()),
            "ambivalenz_mean": safe_float(dataframe["ambivalenz_index"].mean()),
            "dominanzwechsel_rate": safe_float(dataframe["dominanzwechsel"].dropna().mean()),
            "polaritaetswechsel_rate": safe_float(dataframe["polaritaetswechsel"].dropna().mean()),
        }


    return base_block(dataframe, label, teilnehmer, extra_gesamt)

df = load_data()
df = add_transitions(df)
write_json(
    OUTPUT_JSON,
    TITLE,
    INTERPRETATION,
    split_groups(df, analyze_subset)
)
