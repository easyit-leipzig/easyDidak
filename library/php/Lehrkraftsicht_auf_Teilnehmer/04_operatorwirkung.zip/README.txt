FRZK Analysepaket 04_operatorwirkung

1. Export:
   python export_operatorwirkung_lehrkraftdaten.py

2. Darstellung/Auswertung:
   python auswertung_operatorwirkung_lehrkraftdaten.py

Voraussetzungen:
   pip install pandas numpy matplotlib mysql-connector-python
