FRZK Analysepaket 03_nichtlinearitaet

1. Export:
   python export_nichtlinearitaet_lehrkraftdaten.py

2. Darstellung/Auswertung:
   python auswertung_nichtlinearitaet_lehrkraftdaten.py

Voraussetzungen:
   pip install pandas numpy matplotlib mysql-connector-python
