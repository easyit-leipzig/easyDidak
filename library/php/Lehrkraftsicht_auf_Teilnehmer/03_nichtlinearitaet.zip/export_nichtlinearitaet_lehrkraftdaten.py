
from frzk_common import *

ANALYSE_NR = 3
OUTPUT_JSON = "frzk_nichtlinearitaet_lehrkraftdaten.json"
TITLE = "3. Nichtlinearitätsnachweis des FRZK"
INTERPRETATION = "Gleiche Tokenanzahl bei unterschiedlicher semantischer Dichte spricht gegen lineare Bedeutungsakkumulation."

def analyze_subset(dataframe, label):
    dataframe = dataframe.copy()
    teilnehmer = []

    
    dataframe = dataframe[dataframe["token_anzahl"].notna() & (dataframe["token_anzahl"] > 0)].copy()
    dataframe["vektorbetrag"] = np.sqrt((dataframe[DIMENSIONS] ** 2).sum(axis=1))
    dataframe["dichte_pro_token"] = dataframe["d_semantisch"] / dataframe["token_anzahl"]


    for tid, g in dataframe.groupby("teilnehmer_id"):
        
        nonlinearitaet = safe_float(g.groupby("token_anzahl")["d_semantisch"].std().mean())
        teilnehmer.append({
            "teilnehmer_id": int(tid), "n": int(len(g)),
            "datum_von": str(g["datum"].min().date()), "datum_bis": str(g["datum"].max().date()),
            "token_dichte_korrelation": safe_float(g["token_anzahl"].corr(g["d_semantisch"])),
            "token_vektor_korrelation": safe_float(g["token_anzahl"].corr(g["vektorbetrag"])),
            "mittlere_nichtlinearitaet": nonlinearitaet,
            "dichte_pro_token_mean": safe_float(g["dichte_pro_token"].mean()),
            "dichte_pro_token_std": safe_float(g["dichte_pro_token"].std(ddof=0)),
            "d_semantisch_mean": safe_float(g["d_semantisch"].mean()),
            "d_semantisch_std": safe_float(g["d_semantisch"].std(ddof=0)),
        })


    def extra_gesamt(tdf, dataframe):
        
        return {
            "token_dichte_korrelation": safe_float(dataframe["token_anzahl"].corr(dataframe["d_semantisch"])),
            "mittlere_nichtlinearitaet": safe_float(dataframe.groupby("token_anzahl")["d_semantisch"].std().mean()),
            "mittlere_dichte_pro_token": safe_float(dataframe["dichte_pro_token"].mean()),
        }


    return base_block(dataframe, label, teilnehmer, extra_gesamt)

df = load_data()

write_json(
    OUTPUT_JSON,
    TITLE,
    INTERPRETATION,
    split_groups(df, analyze_subset)
)
