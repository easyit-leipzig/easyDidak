
from frzk_common import *

ANALYSE_NR = 10
OUTPUT_JSON = "frzk_systemische_kipppunkte.json"
TITLE = "10. Systemische Kipppunkte des FRZK"
INTERPRETATION = "Kipppunkte liegen vor, wenn Drift, Dichteänderung, Dominanzwechsel und Polaritätswechsel gemeinsam auftreten."

def analyze_subset(dataframe, label):
    dataframe = dataframe.copy()
    teilnehmer = []

    
    dataframe["kipppunkt_score"] = (
        dataframe["delta_vektor"].fillna(0)
        + dataframe["dichte_delta"].abs().fillna(0)
        + dataframe["dominanzwechsel"].fillna(0)
        + dataframe["polaritaetswechsel"].fillna(0)
    )
    threshold = dataframe["kipppunkt_score"].dropna().quantile(0.90)
    dataframe["ist_kipppunkt"] = dataframe["kipppunkt_score"] >= threshold


    for tid, g in dataframe.groupby("teilnehmer_id"):
        
        kipps = g[g["ist_kipppunkt"] == True]
        teilnehmer.append({
            "teilnehmer_id": int(tid), "n": int(len(g)),
            "datum_von": str(g["datum"].min().date()), "datum_bis": str(g["datum"].max().date()),
            "kipppunkt_anzahl": int(len(kipps)),
            "kipppunkt_rate": safe_float(len(kipps) / len(g)) if len(g) else None,
            "kipppunkt_score_mean": safe_float(g["kipppunkt_score"].mean()),
            "kipppunkt_score_max": safe_float(g["kipppunkt_score"].max()),
            "delta_vektor_mean": safe_float(g["delta_vektor"].dropna().mean()),
            "dichte_delta_abs_mean": safe_float(g["dichte_delta"].dropna().abs().mean()),
            "dominanzwechsel_rate": safe_float(g["dominanzwechsel"].dropna().mean()),
            "polaritaetswechsel_rate": safe_float(g["polaritaetswechsel"].dropna().mean()),
        })


    def extra_gesamt(tdf, dataframe):
        
        return {
            "kipppunkt_rate_mean": safe_float(tdf["kipppunkt_rate"].mean()) if not tdf.empty else None,
            "kipppunkt_score_mean": safe_float(tdf["kipppunkt_score_mean"].mean()) if not tdf.empty else None,
            "kipppunkt_score_max": safe_float(tdf["kipppunkt_score_max"].max()) if not tdf.empty else None,
        }


    return base_block(dataframe, label, teilnehmer, extra_gesamt)

df = load_data()
df = add_transitions(df)
write_json(
    OUTPUT_JSON,
    TITLE,
    INTERPRETATION,
    split_groups(df, analyze_subset)
)
