FRZK Analysepaket 10_systemische_kipppunkte

1. Export:
   python export_systemische_kipppunkte.py

2. Darstellung/Auswertung:
   python auswertung_systemische_kipppunkte.py

Voraussetzungen:
   pip install pandas numpy matplotlib mysql-connector-python
