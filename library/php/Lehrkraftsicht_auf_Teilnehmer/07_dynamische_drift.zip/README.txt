FRZK Analysepaket 07_dynamische_drift

1. Export:
   python export_dynamische_drift_lehrkraftdaten.py

2. Darstellung/Auswertung:
   python auswertung_dynamische_drift_lehrkraftdaten.py

Voraussetzungen:
   pip install pandas numpy matplotlib mysql-connector-python
