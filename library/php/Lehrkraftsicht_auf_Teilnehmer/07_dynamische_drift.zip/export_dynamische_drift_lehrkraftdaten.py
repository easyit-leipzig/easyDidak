
from frzk_common import *

ANALYSE_NR = 7
OUTPUT_JSON = "frzk_dynamische_drift_lehrkraftdaten.json"
TITLE = "7. Dynamische Drift des FRZK"
INTERPRETATION = "Dynamische Drift beschreibt Bewegung, Geschwindigkeit und Beschleunigung semantischer Zustände."

def analyze_subset(dataframe, label):
    dataframe = dataframe.copy()
    teilnehmer = []

    
    dataframe["acceleration"] = np.nan
    for _, idx in dataframe.groupby("teilnehmer_id").groups.items():
        idx = list(idx)
        drifts = dataframe.loc[idx, "delta_vektor"].to_numpy(dtype=float)
        for pos in range(2, len(idx)):
            dataframe.loc[idx[pos], "acceleration"] = float(drifts[pos] - drifts[pos-1])


    for tid, g in dataframe.groupby("teilnehmer_id"):
        
        drift_mean = safe_float(g["delta_vektor"].dropna().mean())
        acc_mean = safe_float(g["acceleration"].dropna().mean())
        cos_mean = safe_float(g["cosine_prev"].dropna().mean())
        drift_index = ((drift_mean or 0) + abs(acc_mean or 0) + ((1 - cos_mean) if cos_mean is not None else 0)) / 3
        teilnehmer.append({
            "teilnehmer_id": int(tid), "n": int(len(g)),
            "datum_von": str(g["datum"].min().date()), "datum_bis": str(g["datum"].max().date()),
            "drift_mean": drift_mean,
            "drift_std": safe_float(g["delta_vektor"].dropna().std(ddof=0)),
            "velocity_mean": drift_mean,
            "acceleration_mean": acc_mean,
            "cosine_mean": cos_mean,
            "drift_index": safe_float(drift_index),
        })


    def extra_gesamt(tdf, dataframe):
        
        return {
            "drift_mean": safe_float(tdf["drift_mean"].mean()) if not tdf.empty else None,
            "velocity_mean": safe_float(tdf["velocity_mean"].mean()) if not tdf.empty else None,
            "acceleration_mean": safe_float(tdf["acceleration_mean"].mean()) if not tdf.empty else None,
            "drift_index_mean": safe_float(tdf["drift_index"].mean()) if not tdf.empty else None,
        }


    return base_block(dataframe, label, teilnehmer, extra_gesamt)

df = load_data()
df = add_transitions(df)
write_json(
    OUTPUT_JSON,
    TITLE,
    INTERPRETATION,
    split_groups(df, analyze_subset)
)
