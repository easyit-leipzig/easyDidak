FRZK Analysepaket 05_kohaerenzbildung

1. Export:
   python export_kohaerenzbildung_lehrkraftdaten.py

2. Darstellung/Auswertung:
   python auswertung_kohaerenzbildung_lehrkraftdaten.py

Voraussetzungen:
   pip install pandas numpy matplotlib mysql-connector-python
