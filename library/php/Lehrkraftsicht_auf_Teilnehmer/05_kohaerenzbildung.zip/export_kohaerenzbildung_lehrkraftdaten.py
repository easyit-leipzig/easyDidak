
from frzk_common import *

ANALYSE_NR = 5
OUTPUT_JSON = "frzk_kohaerenzbildung_lehrkraftdaten.json"
TITLE = "5. Kohärenzbildung des FRZK"
INTERPRETATION = "Kohärenzbildung zeigt sich durch geringe Dimensionsstreuung, geringe Drift und hohe Selbstähnlichkeit."

def analyze_subset(dataframe, label):
    dataframe = dataframe.copy()
    teilnehmer = []

    

    for tid, g in dataframe.groupby("teilnehmer_id"):
        
        dim_std_sum = safe_float(g[DIMENSIONS].std(ddof=0).sum())
        mean_abs_dim_diff = safe_float(np.mean([
            abs(g["x_kognition"].mean() - g["x_motivation"].mean()),
            abs(g["x_methodik"].mean() - g["x_regulation"].mean()),
            abs(g["x_kognition"].mean() - g["x_performanz"].mean()),
            abs(g["x_affektiv"].mean() - g["x_sozial"].mean()),
        ]))
        delta_mean = safe_float(g["delta_vektor"].dropna().mean()) or 0
        polar_std = safe_float(g["polaritaet_gesamt"].std(ddof=0)) or 0
        kohaerenzindex = 1 / (1 + (dim_std_sum or 0) + (mean_abs_dim_diff or 0) + delta_mean + polar_std)
        teilnehmer.append({
            "teilnehmer_id": int(tid), "n": int(len(g)),
            "datum_von": str(g["datum"].min().date()), "datum_bis": str(g["datum"].max().date()),
            "dimension_std_sum": dim_std_sum,
            "mean_abs_dim_diff": mean_abs_dim_diff,
            "cosine_mean": safe_float(g["cosine_prev"].dropna().mean()),
            "delta_vektor_mean": safe_float(g["delta_vektor"].dropna().mean()),
            "d_semantisch_std": safe_float(g["d_semantisch"].std(ddof=0)),
            "dominanz_breite": int(g["dominante_dimension"].nunique()),
            "kohaerenzindex": safe_float(kohaerenzindex),
        })


    def extra_gesamt(tdf, dataframe):
        
        return {
            "kohaerenzindex_mean": safe_float(tdf["kohaerenzindex"].mean()) if not tdf.empty else None,
            "dimension_std_sum_mean": safe_float(tdf["dimension_std_sum"].mean()) if not tdf.empty else None,
            "cosine_mean": safe_float(tdf["cosine_mean"].dropna().mean()) if not tdf.empty else None,
        }


    return base_block(dataframe, label, teilnehmer, extra_gesamt)

df = load_data()
df = add_transitions(df)
write_json(
    OUTPUT_JSON,
    TITLE,
    INTERPRETATION,
    split_groups(df, analyze_subset)
)
