FRZK Analysepaket 09_lehrkraft_zustandsoperator

1. Export:
   python export_lehrkraft_zustandsoperator.py

2. Darstellung/Auswertung:
   python auswertung_lehrkraft_zustandsoperator.py

Voraussetzungen:
   pip install pandas numpy matplotlib mysql-connector-python
