
from frzk_common import *

ANALYSE_NR = 9
OUTPUT_JSON = "frzk_lehrkraft_als_zustandsoperator.json"
TITLE = "9. Lehrkraft als Zustandsoperator"
INTERPRETATION = "Die Lehrkraft wird als Zustandsoperator modelliert; Effekte zeigen sich in Driftunterschieden und lehrkraftspezifischen Profilen."

def analyze_subset(dataframe, label):
    dataframe = dataframe.copy()
    teilnehmer = []

    

    for tid, g in dataframe.groupby("teilnehmer_id"):
        
        wechsel = g[g["lehrkraftwechsel"] == 1]
        ohne = g[g["lehrkraftwechsel"] == 0]
        drift_wechsel = safe_float(wechsel["delta_vektor"].mean()) if len(wechsel) else None
        drift_ohne = safe_float(ohne["delta_vektor"].mean()) if len(ohne) else None
        teilnehmer.append({
            "teilnehmer_id": int(tid), "n": int(len(g)),
            "datum_von": str(g["datum"].min().date()), "datum_bis": str(g["datum"].max().date()),
            "n_lehrkraefte": int(g["lehrkraft_id"].nunique()),
            "mittlere_drift": safe_float(g["delta_vektor"].dropna().mean()),
            "mittlere_selbstaehnlichkeit": safe_float(g["cosine_prev"].dropna().mean()),
            "drift_bei_lehrkraftwechsel": drift_wechsel,
            "drift_ohne_lehrkraftwechsel": drift_ohne,
            "operator_sensitivitaet": safe_float(drift_wechsel - drift_ohne) if drift_wechsel is not None and drift_ohne is not None else None,
            "dominanzwechsel_rate": safe_float(g["dominanzwechsel"].dropna().mean()),
            "polaritaetswechsel_rate": safe_float(g["polaritaetswechsel"].dropna().mean()),
        })


    def extra_gesamt(tdf, dataframe):
        
        return {
            "mittlere_drift": safe_float(tdf["mittlere_drift"].mean()) if not tdf.empty else None,
            "mittlere_selbstaehnlichkeit": safe_float(tdf["mittlere_selbstaehnlichkeit"].mean()) if not tdf.empty else None,
            "operator_sensitivitaet": safe_float(tdf["operator_sensitivitaet"].dropna().mean()) if not tdf.empty else None,
        }


    return base_block(dataframe, label, teilnehmer, extra_gesamt)

df = load_data()
df = add_transitions(df)
write_json(
    OUTPUT_JSON,
    TITLE,
    INTERPRETATION,
    split_groups(df, analyze_subset)
)
