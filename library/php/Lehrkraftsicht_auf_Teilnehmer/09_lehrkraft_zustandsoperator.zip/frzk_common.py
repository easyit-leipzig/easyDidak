
import json
from pathlib import Path
import numpy as np
import pandas as pd
import mysql.connector

DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "icas_19_4_2",
    "charset": "utf8mb4",
}

DIMENSIONS = [
    "x_kognition", "x_sozial", "x_affektiv", "x_motivation",
    "x_methodik", "x_performanz", "x_regulation"
]

BASE_SQL = """
SELECT
    id,
    datum,
    lehrkraft_id,
    teilnehmer_id,
    gruppe_id,
    d_semantisch,
    dominante_dimension,
    dominante_dimension_wert,
    polaritaet_gesamt,
    token_anzahl,
    funktionsklassen_anzahl_gesamt,
    x_kognition,
    x_sozial,
    x_affektiv,
    x_motivation,
    x_methodik,
    x_performanz,
    x_regulation
FROM analyze_lehrkraftdaten
WHERE datum IS NOT NULL
ORDER BY teilnehmer_id, datum, id;
"""

def safe_float(value):
    try:
        if value is None or pd.isna(value):
            return None
        return float(value)
    except Exception:
        return None

def load_data():
    conn = mysql.connector.connect(**DB_CONFIG)
    df = pd.read_sql(BASE_SQL, conn)
    conn.close()

    if df.empty:
        raise ValueError("analyze_lehrkraftdaten liefert keine Datensätze.")

    df["datum"] = pd.to_datetime(df["datum"], errors="coerce")

    for col in DIMENSIONS + [
        "d_semantisch", "polaritaet_gesamt", "dominante_dimension_wert",
        "token_anzahl", "funktionsklassen_anzahl_gesamt"
    ]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    df = df.dropna(subset=DIMENSIONS + ["d_semantisch"])
    if df.empty:
        raise ValueError("Nach numerischer Bereinigung bleiben 0 Datensätze übrig.")

    return df.sort_values(["teilnehmer_id", "datum", "id"]).reset_index(drop=True)

def add_transitions(df):
    df = df.copy()
    for col in ["delta_vektor", "cosine_prev", "dominanzwechsel", "polaritaetswechsel", "dichte_delta", "lehrkraftwechsel"]:
        df[col] = np.nan

    for _, idx in df.groupby("teilnehmer_id").groups.items():
        idx = list(idx)
        values = df.loc[idx, DIMENSIONS].to_numpy(dtype=float)

        for pos in range(1, len(idx)):
            prev_i = idx[pos - 1]
            cur_i = idx[pos]
            v1 = values[pos - 1]
            v2 = values[pos]

            df.loc[cur_i, "delta_vektor"] = float(np.linalg.norm(v2 - v1))

            den = np.linalg.norm(v1) * np.linalg.norm(v2)
            df.loc[cur_i, "cosine_prev"] = float(np.dot(v1, v2) / den) if den else np.nan

            df.loc[cur_i, "dominanzwechsel"] = int(
                df.loc[cur_i, "dominante_dimension"] != df.loc[prev_i, "dominante_dimension"]
            )

            df.loc[cur_i, "polaritaetswechsel"] = int(
                df.loc[cur_i, "polaritaet_gesamt"] != df.loc[prev_i, "polaritaet_gesamt"]
            )

            df.loc[cur_i, "dichte_delta"] = float(
                df.loc[cur_i, "d_semantisch"] - df.loc[prev_i, "d_semantisch"]
            )

            df.loc[cur_i, "lehrkraftwechsel"] = int(
                df.loc[cur_i, "lehrkraft_id"] != df.loc[prev_i, "lehrkraft_id"]
            )

    return df

def split_groups(df, analyzer):
    return {
        "alle_lehrkraefte": analyzer(df, "alle_lehrkraefte"),
        "lehrkraft_1": analyzer(df[df["lehrkraft_id"] == 1], "lehrkraft_1"),
        "nicht_lehrkraft_1": analyzer(df[df["lehrkraft_id"] != 1], "nicht_lehrkraft_1"),
    }

def base_block(dataframe, label, teilnehmer, extra_gesamt=None):
    tdf = pd.DataFrame(teilnehmer)
    block = {
        "gruppe": label,
        "n_datensaetze": int(len(dataframe)),
        "n_teilnehmer": int(dataframe["teilnehmer_id"].nunique()) if len(dataframe) else 0,
        "n_lehrkraefte": int(dataframe["lehrkraft_id"].nunique()) if len(dataframe) else 0,
        "zeitraum": {
            "von": str(dataframe["datum"].min().date()) if len(dataframe) else None,
            "bis": str(dataframe["datum"].max().date()) if len(dataframe) else None,
        },
        "gesamt": {},
        "teilnehmer": teilnehmer,
    }
    if extra_gesamt:
        block["gesamt"].update(extra_gesamt(tdf, dataframe))
    return block

def write_json(filename, title, interpretation, data):
    out = {
        "analyse": title,
        "basis": "analyze_lehrkraftdaten",
        "interpretation": interpretation,
        "daten": data,
    }
    path = Path(__file__).resolve().parent / filename
    path.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"JSON erzeugt: {path.resolve()}")
