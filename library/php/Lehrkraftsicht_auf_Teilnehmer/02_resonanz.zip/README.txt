FRZK Analysepaket 02_resonanz

1. Export:
   python export_resonanz_lehrkraftdaten.py

2. Darstellung/Auswertung:
   python auswertung_resonanz_lehrkraftdaten.py

Voraussetzungen:
   pip install pandas numpy matplotlib mysql-connector-python
