import json
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

INPUT = Path(__file__).resolve().parent / "frzk_resonanz_lehrkraftdaten.json"
OUTDIR = Path(__file__).resolve().parent / "plots"
OUTDIR.mkdir(exist_ok=True)

data = json.loads(INPUT.read_text(encoding="utf-8"))

rows = []
for gruppe, block in data["daten"].items():
    for t in block.get("teilnehmer", []):
        row = {"gruppe": gruppe, "teilnehmer_id": t.get("teilnehmer_id"), "n": t.get("n")}
        for field in ['resonanzindex', 'cosine_resonanz_mean', 'dominanz_persistenz', 'polaritaet_persistenz', 'hauptdominanz_anteil']:
            row[field] = t.get(field)
        rows.append(row)

df = pd.DataFrame(rows)
if df.empty:
    raise ValueError("Keine Teilnehmerdaten im JSON gefunden.")

summary = df.groupby("gruppe").agg({field: "mean" for field in ['resonanzindex', 'cosine_resonanz_mean', 'dominanz_persistenz', 'polaritaet_persistenz', 'hauptdominanz_anteil']}).reset_index()

print("\n=== 2. Resonanzvorhersage des FRZK ===")
print(summary.to_string(index=False))

for field in ['resonanzindex', 'cosine_resonanz_mean', 'dominanz_persistenz', 'polaritaet_persistenz', 'hauptdominanz_anteil']:
    if field not in summary.columns:
        continue
    plt.figure(figsize=(10, 6))
    summary.plot(x="gruppe", y=field, kind="bar", legend=False)
    plt.title("2. Resonanzvorhersage des FRZK: " + field)
    plt.xlabel("Vergleichsgruppe")
    plt.ylabel(field)
    plt.tight_layout()
    plt.savefig(OUTDIR / ("abb_" + field + ".png"), dpi=300)
    plt.close()

print("\nTextuelle Auswertung:")
for _, row in summary.iterrows():
    print("\nGruppe:", row["gruppe"])
    for field in ['resonanzindex', 'cosine_resonanz_mean', 'dominanz_persistenz', 'polaritaet_persistenz', 'hauptdominanz_anteil']:
        try:
            print(f"{field}: {row[field]:.4f}")
        except Exception:
            print(f"{field}: {row.get(field)}")

print("\nGrafiken gespeichert in:", OUTDIR.resolve())
