
from frzk_common import *

ANALYSE_NR = 2
OUTPUT_JSON = "frzk_resonanz_lehrkraftdaten.json"
TITLE = "2. Resonanzvorhersage des FRZK"
INTERPRETATION = "Hohe Selbstähnlichkeit, dominante Wiederkehr und stabile Polarität deuten auf Resonanzbildung im FRZK-Raum hin."

def analyze_subset(dataframe, label):
    dataframe = dataframe.copy()
    teilnehmer = []

    

    for tid, g in dataframe.groupby("teilnehmer_id"):
        
        dom_counts = g["dominante_dimension"].value_counts().to_dict()
        main_dom = max(dom_counts, key=dom_counts.get) if dom_counts else None
        dom_persist = safe_float(1 - g["dominanzwechsel"].dropna().mean())
        pol_persist = safe_float(1 - g["polaritaetswechsel"].dropna().mean())
        cos_mean = safe_float(g["cosine_prev"].dropna().mean())
        vals = [v for v in [cos_mean, dom_persist, pol_persist] if v is not None]
        resonanzindex = safe_float(sum(vals) / len(vals)) if vals else None
        teilnehmer.append({
            "teilnehmer_id": int(tid), "n": int(len(g)),
            "datum_von": str(g["datum"].min().date()), "datum_bis": str(g["datum"].max().date()),
            "dominanzverteilung": {str(k): int(v) for k, v in dom_counts.items()},
            "hauptdominanz": main_dom,
            "hauptdominanz_anteil": safe_float(dom_counts[main_dom] / len(g)) if main_dom else None,
            "dominanz_persistenz": dom_persist,
            "polaritaet_persistenz": pol_persist,
            "cosine_resonanz_mean": cos_mean,
            "cosine_resonanz_std": safe_float(g["cosine_prev"].dropna().std(ddof=0)),
            "resonanzindex": resonanzindex,
        })


    def extra_gesamt(tdf, dataframe):
        
        return {
            "mittlerer_resonanzindex": safe_float(tdf["resonanzindex"].mean()) if not tdf.empty else None,
            "cosine_resonanz_mean": safe_float(dataframe["cosine_prev"].dropna().mean()),
            "dominanz_persistenz": safe_float(1 - dataframe["dominanzwechsel"].dropna().mean()),
            "polaritaet_persistenz": safe_float(1 - dataframe["polaritaetswechsel"].dropna().mean()),
        }


    return base_block(dataframe, label, teilnehmer, extra_gesamt)

df = load_data()
df = add_transitions(df)
write_json(
    OUTPUT_JSON,
    TITLE,
    INTERPRETATION,
    split_groups(df, analyze_subset)
)
