
from frzk_common import *

ANALYSE_NR = 6
OUTPUT_JSON = "frzk_emergenz_lehrkraftdaten.json"
TITLE = "6. Emergenzvorhersage des FRZK"
INTERPRETATION = "Emergenz zeigt sich durch globale Muster, Clusterpersistenz und organisierte Übergänge."

def analyze_subset(dataframe, label):
    dataframe = dataframe.copy()
    teilnehmer = []

    

    for tid, g in dataframe.groupby("teilnehmer_id"):
        
        # einfache Cluster-Näherung ohne sklearn: dominante Dimension + Polarität als Zustandsklasse
        g = g.copy()
        g["zustandsklasse"] = g["dominante_dimension"].astype(str) + "_" + g["polaritaet_gesamt"].astype(str)
        seq = g["zustandsklasse"].tolist()
        persistence = sum(1 for i in range(1, len(seq)) if seq[i] == seq[i-1]) / max(1, len(seq)-1)
        transitions = {}
        for i in range(1, len(seq)):
            transitions[(seq[i-1], seq[i])] = transitions.get((seq[i-1], seq[i]), 0) + 1
        probs = np.array(list(transitions.values()), dtype=float)
        entropy = None
        if probs.size:
            probs = probs / probs.sum()
            entropy = float(-(probs * np.log2(probs)).sum())
        teilnehmer.append({
            "teilnehmer_id": int(tid), "n": int(len(g)),
            "datum_von": str(g["datum"].min().date()), "datum_bis": str(g["datum"].max().date()),
            "cluster_persistenz": safe_float(persistence),
            "transition_entropy": safe_float(entropy),
            "d_semantisch_mean": safe_float(g["d_semantisch"].mean()),
            "d_semantisch_std": safe_float(g["d_semantisch"].std(ddof=0)),
            "zustandsklassen": {str(k): int(v) for k, v in g["zustandsklasse"].value_counts().to_dict().items()},
        })


    def extra_gesamt(tdf, dataframe):
        
        return {
            "cluster_persistenz_mean": safe_float(tdf["cluster_persistenz"].mean()) if not tdf.empty else None,
            "transition_entropy_mean": safe_float(tdf["transition_entropy"].mean()) if not tdf.empty else None,
        }


    return base_block(dataframe, label, teilnehmer, extra_gesamt)

df = load_data()
df = add_transitions(df)
write_json(
    OUTPUT_JSON,
    TITLE,
    INTERPRETATION,
    split_groups(df, analyze_subset)
)
