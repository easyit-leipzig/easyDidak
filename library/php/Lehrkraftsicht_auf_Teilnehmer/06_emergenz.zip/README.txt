FRZK Analysepaket 06_emergenz

1. Export:
   python export_emergenz_lehrkraftdaten.py

2. Darstellung/Auswertung:
   python auswertung_emergenz_lehrkraftdaten.py

Voraussetzungen:
   pip install pandas numpy matplotlib mysql-connector-python
